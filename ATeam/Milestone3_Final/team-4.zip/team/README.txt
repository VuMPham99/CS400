A -Team Group 76

Project Name: Quiz Generator

Team Members: 
Ken Bacchiani, Lec 002, Xteam 76, bacchiani@wisc.edu
Mathew Barnard, Lec 002 , Xteam 76, mbarnard3@wisc.edu
Vu Pham, Lec 002 , Xteam 76, vmpham2@wisc.edu
Ziheng Zhang, Lec 002 , Xteam 76, zzhang793@wisc.edu
Tongyu Shen, Lec 002, Xteam 60, tshen34@wisc.edu



Description:
It's a quiz generator based on Json file database.

Current bug:  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Can only save the current database to Yours.json, don't know how to create a new Json File.

If you load a new database, then all the image file must be in the current directory.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!